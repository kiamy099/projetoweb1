document.getElementById('gameForm').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('gameForm').addEventListener('submit', function(event) {
        console.log('Formulário submetido'); // Isso deve aparecer no console
        event.preventDefault();
        // ...
    });
    
    var gameName = document.getElementById('gameName').value;
    var gameLink = document.getElementById('gameLink').value;
    var gameImage = document.getElementById('gameImage').value;

    var li = document.createElement('li');
    li.innerHTML = `
        <strong>${gameName}</strong> - 
        <a href="${gameLink}" target="_blank">Link</a>
        <br>
        <img src="${gameImage}" alt="Capa do jogo" style="width:100px; height:auto;">
    `;

    document.getElementById('gameList').appendChild(li);

    document.getElementById('gameForm').reset();
});
